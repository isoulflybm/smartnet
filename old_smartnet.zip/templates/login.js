$(document).ready(() => {
    if(window.location.protocol != "https:") {
        window.location.href = "https://127.0.0.1:4444/";
    }
    if($.cookie('id')) {
        window.location.href = "/";
    }

    wss = new WebSocket('wss://127.0.0.1:4044/');
    wss.onmessage = (event) => {
        $.cookie('id', event.data.match(/^id=(.*)$/)[1]);
        window.location.reload();
    }
    $('button#enter').click(() => {
        wss.send(
            'login=' + $('input#login').val() +
            '&password=' + $('input#password').val()
        );
    });
})


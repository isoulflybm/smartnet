$(document).ready(() => {
    if(window.location.protocol != "https:") {
        window.location.href = "https://127.0.0.1:4444/";
    }
    if(!$.cookie('id')) {
        window.location.href = "/login.html";
    }
    
    wss = new WebSocket('wss://127.0.0.1:4044/');
    wss.onmessage = (event) => {
        console.log(event.data);
    }
    wss.onopen = () => {
        if($.cookie('id')) {
            wss.send('id=' + $.cookie('id'));
        }
        else {
            document.location.href = '/login.html';
        }
    }
    $('button#exit').click(() => {
        wss.send(
            'exit=' + $.cookie('id')
        );
        $.removeCookie('id');
        document.location.href = '/login.html';
    });
})

#!/usr/bin/python

import pip

#pip.main(['install', 're'])
#pip.main(['install', 'ssl'])
#pip.main(['install', 'asyncio'])
#pip.main(['install', 'http'])
#pip.main(['install', 'websockets'])
#pip.main(['install', 'time'])
#pip.main(['install', 'threading'])

import re
import ssl
import asyncio
import http.server
import http.cookies
import websockets
import time, threading
import hashlib

cookies = http.cookies.SimpleCookie()

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(certfile = "localhost.crt", keyfile = "localhost.key")

def time_app():
    print('Time app on ' + time.ctime())
    threading.Timer(10, time_app).start()
time_app()

class http_app(http.server.BaseHTTPRequestHandler):
   def do_GET(self):
        print('HTTP GET ' + self.path + ' on ' + time.ctime() + '; ' + str(cookies.output()))
        if(self.path == '/'):
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.wfile.write(cookies.output().encode())
            self.end_headers()
            with open('templates/index.html', 'r') as fp:
                data = fp.read()
                self.wfile.write(data.encode())
        else:
            mime = re.search('\.(\w+)$', self.path)
            self.send_response(200)
            self.wfile.write(cookies.output().encode())
            self.end_headers()
            if(re.search('\.js$|\.css$|\.html$', self.path)):
                with open('templates' + self.path, 'r') as fp:
                    data = fp.read()
                    self.send_header("Content-type", "text/" + mime[1])
                    self.wfile.write(data.encode())
            else:
                with open('templates' + self.path, 'rb') as fp:
                    data = fp.read()
                    if(re.search('\.gif$|\.jpg|$\.jpeg|$\.png$', self.path)):
                        self.send_header("Content-type", "image/" + mime[1])
                    else:
                        self.send_header("Content-type", "octet-stream/" + mime[1])
                    self.wfile.write(data)          

   def do_POST(self):
        print('HTTP POST ' + self.path + ' on ' + time.ctime() + '; ' + str(cookies.output()))
        if(self.path == '/'):
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            with open('templates/index.html', 'r') as fp:
                data = fp.read()
                self.wfile.write(data.encode())
        else:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            with open('templates' + self.path, 'r') as fp:
                data = fp.read()
                self.wfile.write(data.encode())       

async def wss_app(websocket, path):
    print('WebSocket ' + path + ' on ' + time.ctime() + '; ' + str(cookies.output()))
    async for message in websocket:
        #await websocket.send(message)
        try:
            login_password = re.search('^login=([\w\d]+)&password=([\w\d]+)$', message)
        except TypeError:
            pass
        else:
            if(login_password):
                await websocket.send(
                    'id=' + hashlib.md5(login_password[0].encode()).hexdigest()
                )

        try:
            id = re.search('^id=([\d\w]+)$')
        except TypeError:
            pass
        else:        
            if(id):
                await websocket.send(
                    'id=' + id
                )

        try:
            exit = re.search('^exit=([\d\w]+)$')
        except TypeError:
            pass
        else:        
            if(exit):
                await websocket.send(
                    'id=' + id
                )

def httpd():
    httpd = http.server.HTTPServer(('127.0.0.1', 4040), http_app)
    httpd.serve_forever()
httpd = threading.Thread(target = httpd)
print('HTTPd start on ' + time.ctime())
httpd.start()

def httpds():
    httpsd = http.server.HTTPServer(('127.0.0.1', 4444), http_app)
    httpsd.socket = ssl_context.wrap_socket(httpsd.socket, server_side = True)
    httpsd.serve_forever()
httpds = threading.Thread(target = httpds)
print('HTTPsd start on ' + time.ctime())
httpds.start()

wssd = websockets.serve(wss_app, '127.0.0.1', 4044, ssl = ssl_context)
print('WSsd start on ' + time.ctime())
asyncio.get_event_loop().run_until_complete(wssd)
asyncio.get_event_loop().run_forever()
